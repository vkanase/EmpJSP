package com.cg.appl.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.appl.entities.Product;
import com.cg.appl.exception.ProductException;
import com.cg.appl.util.DBUtil;

public class ProductDAOImpl implements IProductDAO 
{
	
	private EntityManager entityManager ;
	
	public ProductDAOImpl() 
	{
		entityManager = DBUtil.getEntityManager();
	}
	@Override
	public int addProduct(Product product) throws ProductException 
	{
		int productId = 0 ;
		try 
		{
			entityManager.getTransaction().begin() ;
			
			entityManager.persist(product) ;
			
			productId = product.getId() ;
			
			entityManager.getTransaction().commit() ;
		} 
		catch (Exception e) 
		{
			entityManager.getTransaction().rollback();
			
			throw new ProductException(e.getMessage());
		}
		
		return productId;
	}

	@Override
	public void updateProduct(Product product) throws ProductException 
	{
		try 
		{
			entityManager.getTransaction().begin() ;
			
			entityManager.merge(product) ;
			entityManager.flush();
			
			entityManager.getTransaction().commit() ;
		} 
		catch (Exception e) 
		{
			entityManager.getTransaction().rollback();
			
			throw new ProductException(e.getMessage());
		}
	}

	@Override
	public Product getProduct(int id) throws ProductException 
	{
		Product product = null ;
		
		try 
		{
			entityManager.getTransaction().begin() ;
			
			product = entityManager.find(Product.class, id) ;
			
			entityManager.getTransaction().commit() ;
		} 
		catch (Exception e) 
		{
			entityManager.getTransaction().rollback();
			
			throw new ProductException(e.getMessage());
		}
		
		if( product == null )
		{
			throw new ProductException("No Product Found with id " + id ) ;
		}
		
		return product;
	}

	@Override
	public void removeProduct(int id) throws ProductException 
	{
		try 
		{
			entityManager.getTransaction().begin() ;
			
			Product product = entityManager.find(Product.class, id) ;
			entityManager.remove(product) ;
			
			entityManager.getTransaction().commit() ;
		} 
		catch (Exception e) 
		{
			entityManager.getTransaction().rollback();
			
			throw new ProductException(e.getMessage());
		}

	}
	@Override
	public List<Product> getAllProducts() throws ProductException {
		
		List<Product> products = null ;
		try
		{
			entityManager.getTransaction().begin();
			TypedQuery<Product> query = entityManager.createNamedQuery("GetAllProducts",Product.class);
			products = query.getResultList();
			entityManager.getTransaction().commit();
			
		}catch (Exception e) 
		{
			throw new ProductException(e.getMessage());
		}
		
		if(products == null || products.isEmpty())
		{
			throw new ProductException("No Products to display");
		}
		return products;
	}
	@Override
	public Product getProductByName(String name) throws ProductException {
		
		Product product = null ;
		try
		{
			entityManager.getTransaction().begin();
			String query = "select product from Product product where product.name=:pname" ;
			TypedQuery<Product> query1 = entityManager.createQuery(query, Product.class) ;
			query1.setParameter("pname", name) ;
			product = query1.getSingleResult() ;
			entityManager.getTransaction().commit();
		}
		catch(Exception e)
		{
			entityManager.getTransaction().rollback();
			throw new ProductException("Something went wrong while searching by name");
		}
		return product;
	}
	@Override
	public List<Product> getProductByPrice(float min, float max)
			throws ProductException {
		List<Product> productList = null ;
		
		try
		{
			entityManager.getTransaction().begin();
			
			TypedQuery<Product> query = entityManager.createNamedQuery("GetProductByPrice",Product.class) ;
			query.setParameter("min", min) ;
			query.setParameter("max", max) ;
			productList = query.getResultList() ;
			entityManager.getTransaction().commit();
		}
		
		catch(Exception e)
		{
			throw new ProductException("Product Not FOund");
		}
		if(productList == null || productList.isEmpty())
		{
			throw new ProductException("NO Product Found ") ;
		}
		return productList;
	}

}
