package com.cg.appl.publisher;

import javax.xml.ws.Endpoint;

import com.cg.appl.ws.IProductServices;
import com.cg.appl.ws.ProductServicesImpl;
//http://localhost:9999/products?wsdl
public class ServicePublisher 
{

	public static void main(String[] args) 
	{
		IProductServices productServices = new ProductServicesImpl();
		Endpoint.publish("http://127.0.0.1:9999/products", productServices) ;
		System.out.println("Product Service are published");
	}

}
