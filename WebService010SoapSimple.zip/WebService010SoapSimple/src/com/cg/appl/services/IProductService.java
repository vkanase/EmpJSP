package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Product;
import com.cg.appl.exception.ProductException;

public interface IProductService 
{
	public int addProduct(Product product) throws ProductException;
	public void updateProduct(Product product) throws ProductException;
	public Product getProduct(int id) throws ProductException;
	public void removeProduct(int  id) throws ProductException;
	public List<Product> getAllProducts() throws ProductException ;
	public Product getProductByName(String name) throws ProductException ;
	public List<Product> getProductByPrice( float min , float max ) throws ProductException ;
}
