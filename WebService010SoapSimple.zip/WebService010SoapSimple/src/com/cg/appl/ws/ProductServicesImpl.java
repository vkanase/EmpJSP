package com.cg.appl.ws;

import java.util.List;

import javax.jws.WebService;

import com.cg.appl.entities.Product;
import com.cg.appl.exception.ProductException;

@WebService(endpointInterface="com.cg.appl.ws.IProductServices")
public class ProductServicesImpl implements IProductServices
{
	private com.cg.appl.services.IProductService service ;
	public ProductServicesImpl() 
	{
		service = new com.cg.appl.services.ProductServiceImpl();
	}
	@Override
	public Product getProduct(int id) throws ProductException {
		// TODO Auto-generated method stub
		return service.getProduct(id);
	}
	@Override
	public List<Product> getAllProducts() throws ProductException {
		// TODO Auto-generated method stub
		
		return service.getAllProducts();
	}

}
