package com.cg.appl.ws;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.cg.appl.entities.Product;
import com.cg.appl.exception.ProductException;

@WebService
@SOAPBinding(style=Style.DOCUMENT)
public interface IProductServices 
{
	@WebMethod
	public Product getProduct(int id) throws ProductException ;
	
	@WebMethod
	public List<Product> getAllProducts() throws ProductException ;
}
