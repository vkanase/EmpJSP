package com.cg.appl.clients;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.appl.entities.Product;
import com.cg.appl.exception.ProductException;
import com.cg.appl.ws.IProductServices;

public class TestWebServices 
{

	public static void main(String[] args) 
	{
		//1 Create URL
		//2 Create Qualification Name 
		//3 Create Service
		//4 Create Port
		//5 Procure Services 
		
		//1
		try 
		{
			URL url = new URL("http://localhost:9999/products?wsdl");
			
			//2
			QName qName = new QName("http://ws.appl.cg.com/","ProductServicesImplService") ;
			
			//3
			Service service = Service.create(url, qName) ;
			
			//4
			IProductServices productService = service.getPort(IProductServices.class) ;
			
			//5
			Product product = productService.getProduct(3);
			System.out.println(product);
			
			/*List<Product> plisList = productService.getAllProducts();
			
			for (Product product2 : plisList) 
			{
				System.out.println(product2);
			}*/
		} 
		catch (MalformedURLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (ProductException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
