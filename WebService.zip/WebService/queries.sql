create table products 
(
	id number primary key ,
	name varchar2(20),
	quantity number ,
	price number(8,2)
);

insert into products values(101,'IPad',5,120000);

select * from products ;

select * from products  where name= 'IPad';