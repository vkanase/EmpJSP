package com.capgemini.webservice.service;

import com.capgemini.webservice.dao.IProductDAO;
import com.capgemini.webservice.dao.ProductDAOImpl;
import com.capgemini.webservice.entities.Product;
import com.capgemini.webservice.exception.ProductException;

public class ProductServiceImpl implements IProductService 
{
	IProductDAO productDAO ;
	public ProductServiceImpl() 
	{
		productDAO = new ProductDAOImpl();
	}
	@Override
	public Product getProductByName(String name) throws ProductException {
		// TODO Auto-generated method stub
		System.out.println("IN Service");
		return productDAO.getProductByName(name);
	}

}
