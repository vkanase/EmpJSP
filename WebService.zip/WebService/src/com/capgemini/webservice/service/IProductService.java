package com.capgemini.webservice.service;

import com.capgemini.webservice.entities.Product;
import com.capgemini.webservice.exception.ProductException;

public interface IProductService 
{
	public Product getProductByName(String name) throws ProductException ;
}
