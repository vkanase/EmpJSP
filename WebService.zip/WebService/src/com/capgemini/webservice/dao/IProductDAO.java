package com.capgemini.webservice.dao;

import com.capgemini.webservice.entities.Product;
import com.capgemini.webservice.exception.ProductException;

public interface IProductDAO 
{
	public Product getProductByName(String name) throws ProductException ;
}
