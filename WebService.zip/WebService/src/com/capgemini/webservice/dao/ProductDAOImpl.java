package com.capgemini.webservice.dao;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capgemini.webservice.entities.Product;
import com.capgemini.webservice.exception.ProductException;
import com.capgemini.webservice.util.DBUtil;

public class ProductDAOImpl implements IProductDAO {

	private EntityManager manager ;
	public ProductDAOImpl() 
	{
		manager = DBUtil.getEntityManager();
	}
	@Override
	public Product getProductByName(String name) throws ProductException 
	{
		Product product = null ;
		try
		{
			System.out.println("In DAO");
			manager.getTransaction().begin();
			System.out.println("1");
			String query = "select product from products product where product.name=:pname" ;
			System.out.println("2");
			TypedQuery<Product> query1 = manager.createQuery(query, Product.class) ;
			System.out.println("3");
			query1.setParameter("pname", name) ;
			System.out.println("4");
			product = query1.getSingleResult() ;
			System.out.println(product);
			manager.getTransaction().commit();
			
		}
		catch(Exception e)
		{
			manager.getTransaction().rollback();
			
			throw new ProductException("No Product Found with name " + name);
		}
		return product;
	}

}
