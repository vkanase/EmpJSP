package com.capgemini.webservice.publisher;

import javax.xml.ws.Endpoint;

import com.capgemini.webservice.ws.IProductService;
import com.capgemini.webservice.ws.ProductServiceImpl;

public class ServicePublisher 
{

	public static void main(String[] args) 
	{
		IProductService service = new ProductServiceImpl();
		Endpoint.publish("http://localhost:9999/products", service);
		System.out.println("Service Published");
	}

}
