package com.capgemini.webservice.ws;

import javax.jws.WebService;

import com.capgemini.webservice.entities.Product;
import com.capgemini.webservice.exception.ProductException;

@WebService(endpointInterface="com.capgemini.webservice.ws.IProductService")
public class ProductServiceImpl implements IProductService 
{
	private com.capgemini.webservice.service.IProductService service ;
	public ProductServiceImpl() 
	{
		service = new com.capgemini.webservice.service.ProductServiceImpl();
	}
	@Override
	public Product getProductByName(String name) throws ProductException {
		// TODO Auto-generated method stub
		System.out.println("IN WS");
		return service.getProductByName(name);
	}

}
