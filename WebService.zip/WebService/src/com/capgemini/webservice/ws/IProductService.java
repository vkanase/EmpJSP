package com.capgemini.webservice.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.capgemini.webservice.entities.Product;
import com.capgemini.webservice.exception.ProductException;

@WebService
@SOAPBinding(style=Style.RPC)
public interface IProductService 
{
	@WebMethod
	public Product getProductByName(String name) throws ProductException ;
}
