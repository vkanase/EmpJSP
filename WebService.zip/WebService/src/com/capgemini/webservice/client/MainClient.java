package com.capgemini.webservice.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.capgemini.webservice.entities.Product;
import com.capgemini.webservice.exception.ProductException;
import com.capgemini.webservice.ws.IProductService;

public class MainClient 
{
	public static void main(String[] args) 
	{
		try
		{
			URL url = new URL("http://localhost:9999/products?wsdl");
			
			QName qname =new QName("http://ws.webservice.capgemini.com/", "ProductServiceImplService");
			
			Service service = Service.create(url, qname);
			
			IProductService pservice = service.getPort(IProductService.class);
			Scanner sc  = new Scanner(System.in);
			System.out.println("Enter Product Name");
			String name = sc.next();
			
			Product p = pservice.getProductByName(name);
			System.out.println(p);
			
		}
		catch(MalformedURLException e)
		{
			e.printStackTrace();
		}
		catch (ProductException e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
